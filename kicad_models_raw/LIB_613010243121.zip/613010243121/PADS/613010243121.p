*PADS-LIBRARY-PART-TYPES-V9*

613010243121 613010243121 I CON 6 1 0 0 0
TIMESTAMP 2026.03.17.16.23.44
"Mouser Part Number" 710-613010243121
"Mouser Price/Stock" https://www.mouser.co.uk/ProductDetail/Wurth-Elektronik/613010243121?qs=ZtY9WdtwX54mDpZwGjr8IA%3D%3D
"Manufacturer_Name" Wurth Elektronik
"Manufacturer_Part_Number" 613010243121
"Description" WR-PHD 2.54 mm Socket Header 10p 2 rows Right angle
"Datasheet Link" https://www.we-online.com/catalog/datasheet/613010243121.pdf
GATE 1 10 0
613010243121
1 0 U 1
2 0 U 2
3 0 U 3
4 0 U 4
5 0 U 5
6 0 U 6
7 0 U 7
8 0 U 8
9 0 U 9
10 0 U 10

*END*
*REMARK* SamacSys ECAD Model
252345/1991055/2.50/10/2/Connector
